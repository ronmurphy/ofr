OFR cute set (kawaii / cuddly reskin)
Same ids and formats as the original skin sets, so these files can be swapped in as a theme.
portraits/        28 creatures, 64x64
sprites/items/    17 items, 32x32
sprites/features/ purple_fungus, red_fungus, 32x32
preview_704px/    nearest-neighbour PNG previews (creatures 11x, items/features 22x)
preview_4x/       small PNG previews (4x)
Colour families of the originals are kept so enemies stay readable (purple ogre, blue wizard, red-orange wyvern, gold dragon);
wild animals share the same tainted-gold tone as the originals. Every creature has a face (big eyes, rosy cheeks) and soft shapes.
No 'variant' lines are included; the game tints the ally / corrupted / magic states itself when a drawing has none.
