OFR horror set (cosmic / Lovecraftian reskin)
Same ids and formats as the original skin sets, so these files can be swapped in as a theme.
portraits/        28 creatures, 64x64
sprites/items/    17 items, 32x32
sprites/features/ purple_fungus, red_fungus, 32x32
preview_704px/    nearest-neighbour PNG previews (creatures 11x, items 22x)
preview_4x/       small PNG previews (creatures 4x, items/features 4x)
Colour families of the originals are kept so enemies stay readable; wild animals share one sickly tainted-gold tone.
